# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: dyfo-db-prod3.czynrz5a64r9.ap-south-1.rds.amazonaws.com (MySQL 5.6.40-log)
# Database: iaas
# Generation Time: 2019-07-29 22:55:30 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table cpu_cores
# ------------------------------------------------------------

DROP TABLE IF EXISTS `cpu_cores`;

CREATE TABLE `cpu_cores` (
  `name` varchar(255) NOT NULL,
  `cores` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`name`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `cpu_cores` WRITE;
/*!40000 ALTER TABLE `cpu_cores` DISABLE KEYS */;

INSERT INTO `cpu_cores` (`name`, `cores`, `created_at`, `updated_at`)
VALUES
	('cc1',2,'2019-07-29 03:24:50','2019-07-29 03:24:50'),
	('cc2',4,'2019-07-29 03:24:57','2019-07-29 03:24:57'),
	('cc3',8,'2019-07-29 22:52:36','2019-07-29 22:52:36'),
	('cc4',16,'2019-07-29 22:52:41','2019-07-29 22:52:41');

/*!40000 ALTER TABLE `cpu_cores` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table hard_disks
# ------------------------------------------------------------

DROP TABLE IF EXISTS `hard_disks`;

CREATE TABLE `hard_disks` (
  `name` varchar(255) NOT NULL,
  `size` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`name`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `hard_disks` WRITE;
/*!40000 ALTER TABLE `hard_disks` DISABLE KEYS */;

INSERT INTO `hard_disks` (`name`, `size`, `created_at`, `updated_at`)
VALUES
	('hd1','128','2019-07-29 03:25:05','2019-07-29 03:25:05'),
	('hd2','256','2019-07-29 03:25:09','2019-07-29 03:25:09'),
	('hd3','512','2019-07-29 22:52:18','2019-07-29 22:52:18'),
	('hd4','1024','2019-07-29 22:52:28','2019-07-29 22:52:28');

/*!40000 ALTER TABLE `hard_disks` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table operating_systems
# ------------------------------------------------------------

DROP TABLE IF EXISTS `operating_systems`;

CREATE TABLE `operating_systems` (
  `name` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`name`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `operating_systems` WRITE;
/*!40000 ALTER TABLE `operating_systems` DISABLE KEYS */;

INSERT INTO `operating_systems` (`name`, `version`, `created_at`, `updated_at`)
VALUES
	('Linux','2.0','2019-07-29 22:52:02','2019-07-29 22:52:02'),
	('macOS','10.0','2019-07-29 03:25:31','2019-07-29 03:25:31'),
	('windows','7.0','2019-07-29 03:25:19','2019-07-29 03:25:19');

/*!40000 ALTER TABLE `operating_systems` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table rams
# ------------------------------------------------------------

DROP TABLE IF EXISTS `rams`;

CREATE TABLE `rams` (
  `name` varchar(255) NOT NULL,
  `size` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`name`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `rams` WRITE;
/*!40000 ALTER TABLE `rams` DISABLE KEYS */;

INSERT INTO `rams` (`name`, `size`, `created_at`, `updated_at`)
VALUES
	('ram1',8,'2019-07-29 03:25:43','2019-07-29 03:49:30'),
	('ram2',4,'2019-07-29 03:25:48','2019-07-29 03:49:36'),
	('ram3',2,'2019-07-30 00:52:28','2019-07-30 00:52:28'),
	('ram4',16,'2019-07-30 00:52:33','2019-07-30 00:52:33');

/*!40000 ALTER TABLE `rams` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table user_auth
# ------------------------------------------------------------

DROP TABLE IF EXISTS `user_auth`;

CREATE TABLE `user_auth` (
  `access_token_id` varchar(255) NOT NULL DEFAULT '',
  `user_id` varchar(255) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `last_access_utc` datetime NOT NULL,
  PRIMARY KEY (`access_token_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `email` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL,
  `mobile_no` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `is_master` smallint(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`email`),
  UNIQUE KEY `mobile_no` (`mobile_no`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table virtual_machines
# ------------------------------------------------------------

DROP TABLE IF EXISTS `virtual_machines`;

CREATE TABLE `virtual_machines` (
  `name` varchar(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `operating_system` varchar(255) DEFAULT NULL,
  `ram` varchar(255) DEFAULT NULL,
  `cpu_cores` varchar(255) DEFAULT NULL,
  `hard_disk` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`name`),
  KEY `vm_FK_1` (`operating_system`),
  KEY `vm_FK_2` (`ram`),
  KEY `vm_FK_3` (`cpu_cores`),
  KEY `vm_FK_4` (`hard_disk`),
  KEY `vm_FK_5` (`user_id`),
  CONSTRAINT `vm_FK_1` FOREIGN KEY (`operating_system`) REFERENCES `operating_systems` (`name`),
  CONSTRAINT `vm_FK_2` FOREIGN KEY (`ram`) REFERENCES `rams` (`name`),
  CONSTRAINT `vm_FK_3` FOREIGN KEY (`cpu_cores`) REFERENCES `cpu_cores` (`name`),
  CONSTRAINT `vm_FK_4` FOREIGN KEY (`hard_disk`) REFERENCES `hard_disks` (`name`),
  CONSTRAINT `vm_FK_5` FOREIGN KEY (`user_id`) REFERENCES `users` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
